### Hierarchical clustering ###
X = matrix(c(1, 2, 4, 4, 5, 5, 4, 6, 3, 3), ncol = 2)
hclust_result = hclust(dist(X))

hclust_result$height^2  ## Depth in example
plot(hclust_result, hang = -1)
rect.hclust(hclust_result, h = 3)

### Kmeans clustering ###
data(iris)
iris_tmp = iris[, c('Petal.Length', 'Petal.Width')]
kmeans_result = kmeans(iris_tmp, centers = 3)
plot(iris_tmp, col = kmeans_result$cluster)
points(kmeans_result$centers, pch = 3, col = 1:3, cex = 3)

### Gaussian mixture model ###
if(!require(mclust)) install.packages('mclust')
require(mclust)
mclust_result = Mclust(iris_tmp, G = 3)
summary(mclust_result)
plot(mclust_result)

### Self organizing map ###
if(!require(kohonen)) install.packages('kohonen')
require(kohonen)
som_grid = somgrid(xdim = 4, ydim = 4, topo = 'hexagonal')
som_result = som(as.matrix(iris[, 1:4]),
                 grid = som_grid)
plot(som_result)
