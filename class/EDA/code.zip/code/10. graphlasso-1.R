rm(list = ls())
gc()
######partial correlation and regression model
if(!require(MASS)){install.packages("MASS")};library("MASS")
if(!require(dplyr)){install.packages("dplyr")};library("dplyr")

omega <- matrix(c(1.0, 0.0, 0.5,
                  0.0, 1.0, 0.3,
                  0.5, 0.3, 1.0) ,
                ncol = 3, byrow = TRUE)
sigma <- solve(omega)
round(sigma,2)

set.seed(1)
rdata <- mvrnorm(1e+6, mu = c(0,0,0), sigma) %>% as.data.frame()
colnames(rdata) <- c("x","y","z")
cor(rdata$x, rdata$y)

fit.x <- lm(x~ z-1, data = rdata)
fit.x
res.x <- fit.x$residuals

fit.y <- lm(y ~ z-1, data = rdata)
res.y <- fit.y$residuals
cor(res.x,res.y)


################################
# projection
rm(list = ls())
x1 = c(1, 0, -1)
x2 = c(0, sqrt(2), 0 )
#true model
set.seed(1)
y = 2*x1 + x2 + rnorm(3,0,10)
#fit
x = cbind(x1,x2) %>% as.data.frame()
fit.y = lm(y ~ x1 + x2+ 0, data = x)
haty = predict(fit.y) %>% c()

#generate beta
beta1 = seq(-10,10, length.out = 20)
beta2 = seq(-10,10, length.out = 20)
sample.beta = expand.grid(beta1 = beta1, beta2 = beta2)
cx = matrix(0, nrow = 3, ncol = dim(sample.beta)[1])
for (i in 1:dim(sample.beta)[1]) {
  cx[,i] = sample.beta[i,1] * x1 + sample.beta[i,2]*x2  
}
#graph
library("rgl")
plot3d(x = cx[1, ],y = cx[2, ],z = cx[3, ],phi = 0, bty = "g", 
       col = "gray", type = "p",
       cex = 1, ticktype = "detailed", 
       xlab = "i",ylab = "j",zlab = "k") 

points3d(y[1],y[2], y[3],col = "red", size = 4)
arrow3d(p0 = c(0,0,0), p1 = y, 
        n=2, width = 1/5, type = "l") 
arrow3d(p0 = c(0,0,0), p1 = haty ,
        n=1, width = 1/5, type = "l")
arrow3d(p0 = haty, p1 = y,n=1,width = 1/10,
        thickness = 0.2,type = "l",col = "blue")

#check inner product
t(y - haty) %*% haty 



