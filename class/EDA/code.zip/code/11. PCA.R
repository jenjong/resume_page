##### step0. 환경설정
if(!require(rgl)){install.packages("rgl")}; require(rgl)
if(!require(plotly)){install.packages("plotly")}; require(plotly)
if(!require(reshape2)){install.packages("reshape2")}; require(reshape2)



############### step1. 주성분분석(pca) ###############
data(iris)
head(iris)
ir.descriptors <- iris[, 1:3]
ir.species <- iris[, 5]
ir.pca <- prcomp(ir.descriptors, center = TRUE, scale. = TRUE)
ir.pca
summary(ir.pca)
plot(ir.pca$x, col = ir.species, pch = c(16)) #주성분1,2로만 그린 plot
biplot(ir.pca, cex = c(0.6, 0.8))
plot3d(ir.pca$x[, 1:3], col = as.numeric(factor(iris$Species, levels = c("versicolor", "virginica", "setosa"))))
plot3d(x = ir.pca$x[, 1], y = ir.pca$x[, 2], z = 0, col = as.numeric(factor(iris$Species, levels = c("versicolor", "virginica", "setosa"))))
plot3d(x = ir.pca$x[, 1], y = 0, z = 0, col = as.numeric(factor(iris$Species, levels = c("versicolor", "virginica", "setosa"))))

### plotly package 활용
my_df <- data.frame(ir.pca$x[, 1:3], ir.species)

#Plane surface: PC1, PC2
axis_x <- seq(min(my_df$PC1), max(my_df$PC1), by = 0.05)
axis_y <- seq(min(my_df$PC2), max(my_df$PC2), by = 0.05)
iris_surface <- expand.grid(PC1 = axis_x, PC2 = axis_y, KEEP.OUT.ATTRS = F)
iris_surface$PC3 <- 0
iris_surface <- acast(iris_surface, PC2 ~ PC1, value.var = "PC3") 

# PC1, PC2, PC3 data visualization
plot_ly(my_df, x = ~PC1, y = ~PC2, z = ~PC3, color = ~ir.species, colors = c("red","blue","green")) %>%
  add_markers() %>% 
  add_surface(z = iris_surface, x = axis_x, y = axis_y, showscale = FALSE)

# PC1, PC2 data visualization
plot_ly(my_df, x = ~PC1, y = ~PC2, z = 0, color = ~ir.species, colors = c("red","blue","green")) %>%
  add_markers() %>% 
  add_surface(z = iris_surface, x = axis_x, y = axis_y, showscale = FALSE)



#################### step2. factor score ####################

# score: Add starting point of arrow
plot3d(ir.pca$x)
arrow3d(p0 = c(0, 0, 0), p1 = ir.pca$x[10,], col = 'red', type = "rotation")   # obs1 score
arrow3d(p0 = c(0, 0, 0), p1 = ir.pca$x[60,], col = 'blue', type = "rotation")   # obs2 score



#################### step3. eigenface ####################

### step3_0. 환경설정
if(!require(data.table)){install.packages("data.table")}; require(data.table)
if(!require(dplyr)){install.packages("dplyr")}; require(dplyr)

### step3_1. image data function
# It contains 400 images (rows) of 64x64 grayscale pixels (4096 columns)
load(file="images_formatted.Rdata")
plt_img <- function(x){ image(matrix(x, nrow = 64, byrow = T), col = grey(seq(0, 1, length = 256))) }   # function to plot images 
plt_img(out[1, ]); plt_img(out[2, ]); plt_img(out[3, ])   # Plot of image

##### step3_2. Average face 
# Look for the average face. Group by label then take average of every variable (pixel)
AverageFace <- data.frame(out) %>% mutate(label=y_df) %>% group_by(label) %>% summarise_all(mean)

# Plot the average faces for labels 0, 1 and 2.
plt_img(as.numeric(AverageFace[1, 2:4097])) # For label 0. (1st subject)
plt_img(as.numeric(AverageFace[2, 2:4097])) # For label 1. (2nd subject)
plt_img(as.numeric(AverageFace[3, 2:4097])) # For label 2. (3rd subject)

### step3_3. Perform PCA on the data
# Scale: mean equal to 0, stdv equal to 1
out <- scale(out)
A <- cov(out)   # covariance matrix

# calculate eigenvalues and eigenvectors(largest 20)
eigs <- rARPACK::eigs(A, 4096, which = "LM")
eigenvalues <- eigs$values   # Eigenvalues
eigenvectors <- eigs$vectors   # Eigenvectors

# Check that the 20 biggest eigenvalues account for 76.5 % of the total variance in the dataset
sum(eigenvalues)/sum(eigen(A)$values)   # OUT: [1] 0.7649131

# Plot of eigenfaces
plt_img(eigenvectors[, 1]) # Eigenface 1
plt_img(eigenvectors[, 2]) # Eigenface 2
plt_img(eigenvectors[, 20]) # Eigenface 20

