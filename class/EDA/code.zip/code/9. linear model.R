#### 첫번째 실습 코드
#### http://www-bcf.usc.edu/~gareth/ISL/data.html 에서 Advertising.csv 다운받기

advertise <- read.csv('./data/Advertising.csv')

head(advertise)

fit1 <- lm(data = advertise, formula = sales ~ TV)
fit2 <- lm(data = advertise, formula = sales ~ radio)
fit3 <- lm(data = advertise, formula = sales ~ newspaper)

par(mfcol = c(1,3))

plot(advertise$TV, advertise$sales, col = 'red') + abline(reg = fit1, col = 'blue', lwd = 3)
plot(advertise$radio, advertise$sales, col = 'red') + abline(reg = fit2, col = 'blue', lwd = 3)
plot(advertise$newspaper, advertise$sales, col = 'red') + abline(reg = fit3, col = 'blue', lwd = 3)



#### 두번째 실습 코드

library(gcookbook)
library(ggplot2)
sp <- ggplot(heightweight, aes(x=ageYear, y=heightIn))
sp + geom_point() + stat_smooth(method=lm)

#### 세번째 실습코드
data(mtcars)
head(mtcars)

lm.fit <- lm(formula = mpg ~ hp + wt, data = mtcars)

summary(lm.fit)
library(predict3d)
library(rgl)
predict3d(lm.fit, show.error = TRUE)

rglwidget()


#### 네번째 실습 코드
#### http://www-bcf.usc.edu/~gareth/ISL/data.html 에서 Credit.csv 다운받기
credit <- read.csv('./data/Credit.csv', stringsAsFactors = F)

credit$Student <- ifelse(credit$Student == 'No', 0, 1)

fit4 <- lm(data = credit, Balance ~ Income + factor(Student))
fit5 <- lm(data = credit, Balance ~ Income + factor(Student) + Income*factor(Student))

summary(fit4)
summary(fit5)

par(mfcol = c(1,2))

plot(credit$Income, credit$Balance, col = 0, pch = 16) + 
  abline(coef(fit4)[1], coef(fit4)[2], lwd = 2) + 
  abline(coef(fit4)[1] + coef(fit4)[3], coef(fit4)[2], col = 'red', lwd = 2)

plot(credit$Income, credit$Balance, col = 0, pch = 16) + 
  abline(coef(fit5)[1], coef(fit5)[2], lwd = 2) + 
  abline(coef(fit5)[1] + coef(fit5)[3],
         coef(fit5)[2] + coef(fit5)[4], col = 'red', lwd = 2) +
  legend('topleft', legend = c('student', 'non-student'), lty = 1, col = c('red', 'black'), lwd = 2)




