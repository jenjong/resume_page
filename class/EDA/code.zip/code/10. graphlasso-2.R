########### 상관계수 예제 ##############
cov_mat = matrix(c(1,0,0.5,0,0,1,0.3,0.2,
                   0.5,0.3,1,0,0,0.2,0,1),nrow=4)

j=1; k=2
rho = cov_mat[j,k]/sqrt(cov_mat[j,j]*cov_mat[k,k])
rho

########### 상관계수 피셔검정 ##############
if(!require(MASS)) install.packages('MASS') # mvrnorm{MASS} : 다변량정규분포 표본생성
require(MASS)

set.seed(1)
n=100; j=1; k=2
data = mvrnorm(n, mu=c(0,0,0,0), Sigma=cov_mat)
test_r = cor(data[,j],data[,k])
cor_z_test = function(test_r,n){
  true_r = 0
  t_value = sqrt(n-3)*(0.5*log((1+test_r)/(1-test_r))-
                         0.5*log((1+true_r)/(1-true_r)))
  p_value = 2*pnorm(-abs(t_value))
  cat("z=",t_value, "p-value=",p_value,"cor=",test_r,"\n")
}
cor_z_test(test_r,n)

cor.test(data[,j],data[,k],method="pearson")

########### 편상관계수 예제 (1) ##############
cov_mat = matrix(c(1,0,0.5,0,0,1,0.3,0.2,
                   0.5,0.3,1,0,0,0.2,0,1),nrow=4)
j=1; k=2
S11 = cov_mat[c(j,k),c(j,k)]
S12 = cov_mat[c(j,k),-c(j,k)]
S21 = cov_mat[-c(j,k),c(j,k)]
S22 = cov_mat[-c(j,k),-c(j,k)]
cov_mat
S11; S12; S21; S22

########### 편상관계수 예제 (2) ##############
partial_mat = S11 - S12%*%solve(S22)%*%S21
partial_mat

########### 편상관계수 예제 (3) ##############
partial_rho = partial_mat[1,2]/sqrt(partial_mat[1,1]*partial_mat[2,2])
partial_rho


########### 편상관계수 그래프 ##############
if(!require(igraph)) install.packages('igraph')
require(igraph)
precision_mat = matrix(c(1,0,0.5,0,0,1,0.3,0.2,
                           0.5,0.3,1,0,0,0.2,0,1),nrow=4)
precision_mat_tmp = precision_mat
precision_mat_tmp[precision_mat != 0] = 1
g = graph.adjacency(precision_mat_tmp,diag=FALSE,  mode = 'undirected')
g = simplify(g)
plot(g)


########### 회귀계수와 편상관계수 관계 ##############

precision_mat = matrix(c(1,0,0.5,0,0,1,0.3,0.2,
                 0.5,0.3,1,0,0,0.2,0,1),nrow=4)
j=1; k=2
reg_beta = -precision_mat[j,k]/precision_mat[j,j]
partial_rho = precision_mat[j,k]/sqrt(precision_mat[j,j]*precision_mat[k,k])
reg_beta; precision_mat[j,k]; partial_rho

require(MASS)
Sigma = solve(precision_mat)
data = mvrnorm(n=100, mu=c(0,0,0,0), Sigma=Sigma)
colnames(data) = c("x1","x2","x3","x4")
y = data[,1]
x = data[,-1]
summary(lm(y~-1+x))


########### 가우시안 그래피컬 회귀분석 추정 ##############
if(!require(glmnet)) install.packages('glmnet')
require(MASS)
require(glmnet)

precision_mat = matrix(c(1,0,0.5,0,0,1,0.3,0.2,
                         0.5,0.3,1,0,0,0.2,0,1),nrow=4)
Sigma = solve(precision_mat)
set.seed(1)
data = mvrnorm(n=100, mu=c(0,0,0,0), Sigma=Sigma)
colnames(data) = c("x1","x2","x3","x4")
 
lambda=0.5; j=1
reg = glmnet(x=data[,-j],y=data[,j],alpha=1,
                         lambda=lambda,intercept=FALSE)
coef(reg)


########### 이변량정규분포3차원그래프 ##############
if(!require(mvtnorm)) install.packages('mvtnorm')  # dmvnorm{mvtnorm} 다변량 정규분포 값 추출
if(!require(plotly)) install.packages('plotly')
require(mvtnorm)
require(plotly)

x1 = seq(-3,3,length.out=100)
x2 = seq(-3,3,length.out=100)
mu = c(0,0)
sig = matrix(c(2,1,1,1),nrow=2)
fx = outer(x1, x2, function(x1,x2) { 
                    dmvnorm(cbind(x1, x2),mean=mu, sigma=sig) })

# persp(x1,x2,fx,theta=30,phi=20)
plot_ly(x = x1, y = x2, z = fx) %>% add_surface()



# rho_fun = function(cov_mat,j,k){
#   rho = cov_mat[j,k]/sqrt(cov_mat[j,j]*cov_mat[k,k])
#   return(rho)
# }
# rho_fun(cov_mat,1,2)

# cor_mat = matrix(NA,nrow=4,ncol=4)
# for (j in 1:4){
#   for (k in 1:4){
#     cor_mat[j,k] = rho_fun(cov_mat,j,k)
#   }
# }
# cor_mat

# t-test
# test_r = rho_fun(cov_mat,1,3)
# n = 30
# cor_t_test = function(test_r,n){
#   true_r = 0
#   t_value = test_r*sqrt(n-2)/sqrt(1-cor^2)
#   p_value = 2*pt(-abs(t_value),df=n-2)
#   cat("t=",t_value,"df"=n-2, "p-value=",p_value,"cor=",sample_r)
# }
