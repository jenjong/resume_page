if(!require(ggplot2)){install.packages("ggplot2"); library(ggplot2)}
if(!require(reshape2)){install.packages("reshape2"); library(reshape2)}
if(!require(dplyr)){install.packages("dplyr"); library(dplyr)}
library(plyr)
library(gcookbook)
cabbage_exp
ggplot(cabbage_exp, aes(x=Date, y=Weight, fill= Cultivar))  + 
  geom_bar(stat="identity") + geom_text(aes(y=Weight+0.1, label=Weight))


ggplot(cabbage_exp, aes(x=Date, y=Weight, fill= Cultivar))  + 
  geom_bar(stat="identity", position = 'dodge') +
  geom_text(aes(label=Weight), vjust=1.5, colour="white",
            position=position_dodge(.9), size=3)
ggplot(cabbage_exp, aes(x=Date, y=Weight, fill= Cultivar))  + 
  geom_bar(stat="identity") + 
  geom_text(aes(y=Weight+0.1, label=Weight))
ggplot(cabbage_exp, aes(x=Date, y=Weight, fill= Cultivar))  + 
  geom_bar(stat="identity", position = 'dodge')+
  geom_text(aes(label=Weight), vjust=1.5, colour="white",
            position=position_dodge(.9), size=3)

ce <- ddply(cabbage_exp, "Date", transform,
            percent_weight = Weight / sum(Weight) * 100)
ggplot(ce, aes(x=Date, y=percent_weight, fill=Cultivar)) +
  geom_bar(stat="identity")

ce <- ddply(cabbage_exp, "Date", transform,
            percent_weight = Weight / sum(Weight) * 100)
ggplot(ce, aes(x=Date, y=percent_weight, fill=Cultivar)) +
  geom_bar(stat="identity")


tophit <- tophitters2001[1:25, ] 
head(tophit[, c("name", "lg", "avg")], n = 5)
ggplot(tophit, aes(x=avg, y=name)) + geom_point()
ggplot(tophit, aes(y=reorder(name, avg), x=avg)) +
  geom_point(size=3) + # Use a larger dot
  theme_bw() +
  theme(axis.text.x = element_text(angle=60, hjust=1),
        panel.grid.major.y = element_blank(),
        panel.grid.minor.y = element_blank(),
        panel.grid.major.x = element_line(colour="grey60",
                                          linetype="dashed"))
ggplot(tophit, aes(y=reorder(name, avg), x=avg)) +
  geom_point(size=3) + # Use a larger dot
  theme_bw() +
  theme(axis.text.x = element_text(angle=60, hjust=1),
        panel.grid.major.y = element_blank(),
        panel.grid.minor.y = element_blank(),
        panel.grid.major.x = element_line(colour="grey60",
                                          linetype="dashed"))
nameorder <- tophit$name[order(tophit$lg, tophit$avg)]
tophit$name = factor(tophit$name, levels=nameorder)

ggplot(tophit, aes(x=avg, y=name)) +
  geom_point(size=3, aes(colour=lg)) +
  theme(panel.grid.major.y = element_blank()) +
  facet_grid(lg ~ ., scales="free_y", space="free_y")
nameorder <- tophit$name[order(tophit$lg, tophit$avg)]
tophit$name = factor(tophit$name, levels=nameorder)

ggplot(tophit, aes(x=avg, y=name)) +
  geom_point(size=3, aes(colour=lg)) +
  theme(panel.grid.major.y = element_blank()) +
  facet_grid(lg ~ ., scales="free_y", space="free_y")

head(uspopage, n = 5)
ggplot(uspopage, aes(x=Year, y=Thousands, fill=AgeGroup)) + geom_area()
uspopage_prop <- ddply(uspopage, "Year", transform,
                       Percent = Thousands / sum(Thousands) * 100)
ggplot(uspopage_prop, aes(x=Year, y=Percent, fill=AgeGroup)) +
  geom_area(colour="black",alpha=.4)
clim <- subset(climate, Source == "Berkeley",
               select=c("Year", "Anomaly10y", "Unc10y"))
head(clim, n = 5)
clim <- subset(climate, Source == "Berkeley",
               select=c("Year", "Anomaly10y", "Unc10y"))
ggplot(clim, aes(x=Year, y=Anomaly10y)) +
  geom_ribbon(aes(ymin=Anomaly10y-Unc10y, ymax=Anomaly10y+Unc10y),
              alpha=0.2) +
  geom_line()
clim <- subset(climate, Source == "Berkeley",
               select=c("Year", "Anomaly10y", "Unc10y"))
ggplot(clim, aes(x=Year, y=Anomaly10y)) +
  geom_ribbon(aes(ymin=Anomaly10y-Unc10y, ymax=Anomaly10y+Unc10y),
              alpha=0.2) +  geom_line()

if(!require(ggplot2)){install.packages("ggplot2"); library(ggplot2)}
if(!require(reshape2)){install.packages("reshape2"); library(reshape2)}
if(!require(dplyr)){install.packages("dplyr"); library(dplyr)}
library(plyr)
library(gcookbook)
head(diamonds)
sp <- ggplot(diamonds, aes(x=carat, y=price))
sp + geom_point()
sp + geom_point(alpha=.01)
sp + stat_bin2d(bins=50) +
  scale_fill_gradient(low="lightblue", high="red", limits=c(0, 6000))
sp + stat_binhex() +
  scale_fill_gradient(low="lightblue", high="red")
head(heightweight, n = 5)
sp <- ggplot(heightweight, aes(x=ageYear, y=heightIn))
sp + geom_point() + stat_smooth(method=lm)
sps <- ggplot(heightweight, aes(x=ageYear, y=heightIn, colour=sex)) +
  geom_point() +
  scale_colour_brewer(palette="Set1") + facet_grid(.~sex)
sps + geom_point() + stat_smooth(method=lm)
sps <- ggplot(heightweight, aes(x=ageYear, y=heightIn, colour=sex)) +
  geom_point() +
  scale_colour_brewer(palette="Set1") + facet_grid(.~sex)
sps + geom_point() + stat_smooth(method=loess)

if(!require(ggplot2)){install.packages("ggplot2"); library(ggplot2)}
if(!require(reshape2)){install.packages("reshape2"); library(reshape2)}
if(!require(dplyr)){install.packages("dplyr"); library(dplyr)}
library(plyr)
library(gcookbook)
head(wind)
ggplot(wind, aes(x=DirCat, fill=SpeedCat)) +
  geom_histogram(binwidth=15, origin=-7.5) +
  scale_x_continuous(limits=c(0,360))
ggplot(wind, aes(x=DirCat, fill=SpeedCat)) +
  geom_histogram(binwidth=15, origin=-7.5) +
  coord_polar() +
  scale_x_continuous(limits=c(0,360))
md <- data.frame(deaths = as.numeric(mdeaths),
                 month = as.numeric(cycle(mdeaths)))
head(md)
md <- ddply(md, "month", summarise, deaths = mean(deaths))
head(md)
p <- ggplot(md, aes(x=month, y=deaths)) + geom_line() +
  scale_x_continuous(breaks=1:12)
p
p <- ggplot(md, aes(x=month, y=deaths)) + geom_line() +
  scale_x_continuous(breaks=1:12)
p + coord_polar()
